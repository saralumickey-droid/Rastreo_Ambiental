import { FormEvent, useState } from "react";
import { Link } from "react-router-dom";
import * as React from "react";

export default function Notificaciones() {
  const [msg, setMsg] = useState("");
  const [sent, setSent] = useState("");

  function send(e: FormEvent) {
    e.preventDefault();
    if (msg.trim()) setSent(`Notificación enviada: ${msg}`);
  }

  return (
    <div className="page-container">
      <Link to="/administrador/dashboard" className="btn btn-dark">
        Volver
      </Link>
      <h2 className="page-title">Enviar notificación masiva</h2>

      <form className="card form-card" onSubmit={send}>
        <input
          className="form-control"
          placeholder="Mensaje"
          value={msg}
          onChange={(e) => setMsg(e.target.value)}
        />
        <button className="btn btn-primary">
          Enviar a todos los usuarios
        </button>
        {sent && <p className="success-message">{sent}</p>}
      </form>
    </div>
  );
}