import { FormEvent, useState } from "react";
import { Link } from "react-router-dom";
import * as React from "react";

export default function Rutas() {
  const [nombre, setNombre] = useState("");
  const [desc, setDesc] = useState("");
  const [saved, setSaved] = useState(false);

  function save(e: FormEvent) {
    e.preventDefault();
    setSaved(true);
  }

  return (
    <div className="page-container">
      <Link to="/administrador/dashboard" className="btn btn-dark">
        Volver
      </Link>
      <h2 className="page-title">Gestión de rutas</h2>

      <form className="card form-card" onSubmit={save}>
        <input
          className="form-control"
          placeholder="Nombre ruta"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
        <textarea
          className="form-control"
          placeholder="Descripción / trayecto"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
        />
        <button className="btn btn-success">Guardar ruta</button>
        {saved && <p className="success-message">Ruta guardada correctamente.</p>}
      </form>
    </div>
  );
}