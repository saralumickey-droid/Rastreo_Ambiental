import { useState } from "react";
import { Link } from "react-router-dom";
import * as React from "react";

export default function Reciclaje() {
  const [out, setOut] = useState("");

  function geo() {
    if (!navigator.geolocation) {
      setOut("La geolocalización no está disponible.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (p) =>
        setOut(
          `Latitud: ${p.coords.latitude} | Longitud: ${p.coords.longitude}`
        ),
      () => setOut("No se pudo obtener la ubicación.")
    );
  }

  return (
    <div className="page-container">
      <Link to="/ciudadano/dashboard" className="btn btn-dark">
        Volver
      </Link>
      <h2 className="page-title">Punto de reciclaje cercano</h2>

      <div className="card form-card">
        <button className="btn btn-success" onClick={geo}>
          Detectar ubicación
        </button>
        {out && <p className="success-message">{out}</p>}
      </div>
    </div>
  );
}