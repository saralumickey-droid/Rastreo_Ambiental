import { FormEvent, useState } from "react";
import { Link } from "react-router-dom";
import * as React from "react";

export default function Reportes() {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [sent, setSent] = useState(false);

  function submit(e: FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div className="page-container">
      <Link to="/ciudadano/dashboard" className="btn btn-dark">
        Volver
      </Link>
      <h2 className="page-title">Reportar incidente</h2>

      <form className="card form-card" onSubmit={submit}>
        <input
          className="form-control"
          placeholder="Título del incidente"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          className="form-control"
          placeholder="Descripción"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
        />
        <input type="file" className="form-control" />
        <button className="btn btn-danger">Enviar reporte</button>
        {sent && (
          <p className="success-message">Reporte preparado correctamente.</p>
        )}
      </form>
    </div>
  );
}